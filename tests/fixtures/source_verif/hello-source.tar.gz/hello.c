#include <stdio.h>

int main() {
    printf("Hello from Source!\n");
    return 0;
}
